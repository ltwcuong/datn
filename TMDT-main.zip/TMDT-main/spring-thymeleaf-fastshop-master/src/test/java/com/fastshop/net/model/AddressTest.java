package com.fastshop.net.model;

import org.junit.jupiter.api.Test;

public class AddressTest {
    @Test
    void testCanEqual() {

    }

    @Test
    void testEquals() {

    }

    @Test
    void testGetChoose() {

    }

    @Test
    void testGetId() {

    }

    @Test
    void testGetPlace() {

    }

    @Test
    void testGetUsername() {

    }

    @Test
    void testHashCode() {

    }

    @Test
    void testSetChoose() {

    }

    @Test
    void testSetId() {

    }

    @Test
    void testSetPlace() {

    }

    @Test
    void testSetUsername() {

    }

    @Test
    void testToString() {

    }
}
