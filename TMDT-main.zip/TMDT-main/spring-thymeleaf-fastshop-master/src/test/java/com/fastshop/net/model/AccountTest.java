package com.fastshop.net.model;

import org.junit.jupiter.api.Test;

public class AccountTest {
    @Test
    void testCanEqual() {

    }

    @Test
    void testEquals() {

    }

    @Test
    void testGetActive() {

    }

    @Test
    void testGetAtms() {

    }

    @Test
    void testGetAuthorities() {

    }

    @Test
    void testGetComments() {

    }

    @Test
    void testGetEmail() {

    }

    @Test
    void testGetFullname() {

    }

    @Test
    void testGetHistories() {

    }

    @Test
    void testGetOrders() {

    }

    @Test
    void testGetPassword() {

    }

    @Test
    void testGetPhone() {

    }

    @Test
    void testGetUsername() {

    }

    @Test
    void testHashCode() {

    }

    @Test
    void testSetActive() {

    }

    @Test
    void testSetAtms() {

    }

    @Test
    void testSetAuthorities() {

    }

    @Test
    void testSetComments() {

    }

    @Test
    void testSetEmail() {

    }

    @Test
    void testSetFullname() {

    }

    @Test
    void testSetHistories() {

    }

    @Test
    void testSetOrders() {

    }

    @Test
    void testSetPassword() {

    }

    @Test
    void testSetPhone() {

    }

    @Test
    void testSetUsername() {

    }

    @Test
    void testToString() {

    }
}
