package com.fastshop.net.model;

import org.junit.jupiter.api.Test;

public class ATMTest {
    @Test
    void testCanEqual() {

    }

    @Test
    void testEquals() {

    }

    @Test
    void testGetAccount() {

    }

    @Test
    void testGetCompany() {

    }

    @Test
    void testGetId() {

    }

    @Test
    void testGetName() {

    }

    @Test
    void testGetNumber() {

    }

    @Test
    void testGetValid() {

    }

    @Test
    void testHashCode() {

    }

    @Test
    void testSetAccount() {

    }

    @Test
    void testSetCompany() {

    }

    @Test
    void testSetId() {

    }

    @Test
    void testSetName() {

    }

    @Test
    void testSetNumber() {

    }

    @Test
    void testSetValid() {

    }

    @Test
    void testToString() {

    }
}
