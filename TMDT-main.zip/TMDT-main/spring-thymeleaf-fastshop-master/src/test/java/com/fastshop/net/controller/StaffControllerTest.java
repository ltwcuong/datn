package com.fastshop.net.controller;

import org.junit.jupiter.api.Test;

public class StaffControllerTest {
    @Test
    void testCategory() {

    }

    @Test
    void testChange() {

    }

    @Test
    void testConfirm() {

    }

    @Test
    void testDetails() {

    }

    @Test
    void testDicsount() {

    }

    @Test
    void testGetAuth() {

    }

    @Test
    void testHome() {

    }

    @Test
    void testProduct() {

    }

    @Test
    void testProducts() {

    }

    @Test
    void testRedetail() {

    }

    @Test
    void testReport() {

    }

    @Test
    void testStatus() {

    }
}
