package com.fastshop.net.model;

import org.junit.jupiter.api.Test;

public class DiscountTest {
    @Test
    void testCanEqual() {

    }

    @Test
    void testEquals() {

    }

    @Test
    void testGetDateEnd() {

    }

    @Test
    void testGetDateFrom() {

    }

    @Test
    void testGetDolar() {

    }

    @Test
    void testGetFree() {

    }

    @Test
    void testGetId() {

    }

    @Test
    void testGetNumber() {

    }

    @Test
    void testGetProducts() {

    }

    @Test
    void testHashCode() {

    }

    @Test
    void testSetDateEnd() {

    }

    @Test
    void testSetDateFrom() {

    }

    @Test
    void testSetDolar() {

    }

    @Test
    void testSetFree() {

    }

    @Test
    void testSetId() {

    }

    @Test
    void testSetNumber() {

    }

    @Test
    void testSetProducts() {

    }

    @Test
    void testToString() {

    }
}
