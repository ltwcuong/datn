package com.fastshop.net;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetApplicationTests {

	@Test
	void contextLoads() {
	}

}
