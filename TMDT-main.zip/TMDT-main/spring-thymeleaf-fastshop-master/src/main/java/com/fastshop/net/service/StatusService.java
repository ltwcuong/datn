package com.fastshop.net.service;

import com.fastshop.net.model.Status;

public interface StatusService {
    Status findById(Integer id);
}
